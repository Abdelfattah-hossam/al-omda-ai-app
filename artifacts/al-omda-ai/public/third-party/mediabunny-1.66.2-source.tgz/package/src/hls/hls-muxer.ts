/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

import { MediaCodec, validateAudioChunkMetadata, validateVideoChunkMetadata } from '../codec';
import { Quality } from '../encode';
import { Logging } from '../logging';
import { EncodedAudioPacketSource, EncodedVideoPacketSource } from '../media-source';
import {
	arrayArgmax,
	assert,
	AsyncMutex,
	findLastIndex,
	joinPaths,
	textEncoder,
	toArray,
	toDataView,
	UNDETERMINED_LANGUAGE,
} from '../misc';
import { Muxer } from '../muxer';
import {
	Output,
	OutputAudioTrack,
	OutputSubtitleTrack,
	OutputTrack,
	OutputVideoTrack,
	TrackType,
} from '../output';
import {
	HlsOutputFormat,
	HlsOutputFormatOptions,
	HlsOutputPlaylistInfo,
	HlsOutputSegmentInfo,
	OutputFormat,
} from '../output-format';
import { Writer } from '../writer';
import { EncodedPacket } from '../packet';
import { SubtitleCue, SubtitleMetadata } from '../subtitles';
import { NullTarget, PathedTarget, Target, TargetRequest } from '../target';
import { HLS_MIME_TYPE, TIMESTAMP_PRIV_OWNER } from './hls-misc';
import { secondsToMpegTsTimestamp } from '../mpeg-ts/mpeg-ts-misc';
import type { IsobmffMuxer } from '../isobmff/isobmff-muxer';

// Maps from WebCodecs to what HLS wants
const toHlsCodecString = (codecString: string) => {
	if (codecString === 'opus') {
		return 'Opus';
	}
	if (codecString === 'flac') {
		return 'fLaC';
	}
	if (codecString === 'mp3' || codecString === 'mp4a.69' || codecString === 'mp4a.6B' || codecString === 'mp4a.6b') {
		return 'mp4a.40.34';
	}

	return codecString;
};

type HlsTrackData = {
	track: OutputTrack;
	packets: EncodedPacket[];
	playlist: Playlist;
	info: {
		type: 'video';
		decoderConfig: VideoDecoderConfig;
		primingPacket: EncodedPacket | null;
	} | {
		type: 'audio';
		decoderConfig: AudioDecoderConfig;
		primingPacket: EncodedPacket | null;
	};
};
type HlsVideoTrackData = HlsTrackData & { info: { type: 'video' } };
type HlsAudioTrackData = HlsTrackData & { info: { type: 'audio' } };

type PlaylistSegment = {
	path: string;
	duration: number;
	timestamp: number;
	byteSize: number;
	byteOffset: number | null;
	info: HlsOutputSegmentInfo | null;
};

type Playlist = {
	id: number;
	path: string;
	tracks: OutputTrack[];
	segmentFormat: OutputFormat;

	currentSegmentStartTimestamp: number | null;
	currentSegmentStartTimestampIsFixed: boolean;
	nextSegmentId: number;
	initSegment: PlaylistSegment | null;
	writtenSegments: PlaylistSegment[];
	peakBitrate: number | null;
	averageBitrate: number | null;
	mediaSequence: number;
	done: boolean;

	singleFile: {
		target: Target;
		path: string;
		nextOffset: number;
		info: HlsOutputSegmentInfo;
		/**
		 * Used for the special-cased logic where single file mode is enabled with fMP4. In this case, we write out a
		 * segments file which is also a perfectly valid standalone fMP4 valid.
		 */
		fragmentedIsobmffOutput: FragmentedIsobmffOutput | null;
	} | null;

	// For HLS, having a single mutex is too coarse. Every playlist is basically independent and therefore we can have
	// a per-playlist mutex instead of a per-muxer one. This means two packets from different playlists coming in don't
	// block each other.
	mutex: AsyncMutex;
};

type PlaylistDeclaration = {
	playlist: Playlist;
	groupId: string | null;
	noUri: boolean;
	references: PlaylistDeclaration[];
};

type FragmentedIsobmffOutput = {
	output: Output;
	videoSource: EncodedVideoPacketSource | null;
	audioSource: EncodedAudioPacketSource | null;
	firstMoofPosition: number | null;
	currentFileSize: number;
};

export class HlsMuxer extends Muxer {
	format: HlsOutputFormat;
	getPlaylistPath: NonNullable<HlsOutputFormatOptions['getPlaylistPath']>;
	getSegmentPath: NonNullable<HlsOutputFormatOptions['getSegmentPath']>;
	getInitPath: NonNullable<HlsOutputFormatOptions['getInitPath']>;

	targetSegmentDuration: number;
	trackDatas: HlsTrackData[] = [];
	closedTracks = new Set<OutputTrack>();
	singleFilePerPlaylist: boolean;
	isLive: boolean;
	maxLiveSegmentCount: number;
	mediaTimestampBase: number;
	firstPacketTimestamp: number | null = null;
	isRelativeToUnixEpoch = false;
	globalTargetDuration: number;
	numWrittenMasterPlaylists = 0;

	playlists: Playlist[] = [];
	playlistDeclarations: PlaylistDeclaration[] = [];

	constructor(output: Output, format: HlsOutputFormat) {
		if (!(output._target instanceof PathedTarget)) {
			throw new TypeError('HLS outputs require `OutputOptions.target` to be a PathedTarget.');
		}

		super(output);

		this.format = format;
		this.targetSegmentDuration = format._options.targetDuration ?? 2;
		this.singleFilePerPlaylist = format._options.singleFilePerPlaylist ?? false;
		this.isLive = format._options.live ?? false;
		this.maxLiveSegmentCount = format._options.maxLiveSegmentCount ?? Infinity;
		this.mediaTimestampBase = format._options.mediaTimestampBase ?? 10;
		this.globalTargetDuration = 0;

		this.getPlaylistPath = format._options.getPlaylistPath
			?? (({ n }) => `playlist-${n}.m3u8`);
		this.getSegmentPath = format._options.getSegmentPath
			?? (info => info.isSingleFile
				? `segments-${info.playlist.n}${info.format.fileExtension}`
				: `segment-${info.playlist.n}-${info.n}${info.format.fileExtension}`);
		this.getInitPath = format._options.getInitPath
			?? (playlist => `init-${playlist.n}${playlist.segmentFormat.fileExtension}`);
	}

	async start(): Promise<void> {
		const release = await this.mutex.acquire();

		try {
			const someRelative = this.output.tracks.some(t => t.metadata.isRelativeToUnixEpoch);
			const someNotRelative = this.output.tracks.some(t => !t.metadata.isRelativeToUnixEpoch);
			if (someRelative && someNotRelative) {
				throw new Error(
					'All tracks must agree on `relativeToUnixEpoch`: some tracks are relative to the Unix epoch and'
					+ ' some are not.',
				);
			}
			this.isRelativeToUnixEpoch = someRelative;

			// Upon starting, we now need to assign the tracks to separate playlists. This assignment will make use of
			// the track pairability information provided by the user as well as other metadata specified on the tracks.
			// The resulting master playlist should preserve track pairability; meaning that all tracks that are
			// pairable remain pairable, and no two tracks become pairable that are meant to be mutually exclusive.
			// The algorithm determines "groups" by enumerating all pairable tracks for each track, and then
			// materializes each group either as #EXT-X-MEDIA tags or top-level #EXT-X-STREAM-INF tags. The algorithm is
			// biased towards video being the top-level grouping, since that's the standard practice.

			const groupAssignment = new Map<OutputTrack, string[]>();
			const groups: {
				name: string;
				key: string;
				tracks: OutputTrack[];
				needsEmit: boolean;
				firstNoUri: boolean;
			}[] = [];

			let hasVideo = false;
			let illegalPairingDetected = false;
			let keyPacketsOnlyPairingWarned = false;

			// First, let's build the "sibling" groups induced by track pairability
			for (const track of this.output.tracks) {
				if (track.type === 'video') {
					hasVideo = true;
				}

				const pairableGroups = new Map<MediaCodec, OutputTrack[]>();

				for (const otherTrack of this.output.tracks) {
					if (track === otherTrack) {
						continue;
					}

					if (!track.canBePairedWith(otherTrack)) {
						continue;
					}

					if (track.type === otherTrack.type) {
						if (!illegalPairingDetected) {
							Logging._warn(
								`Illegal pairing of two ${track.type} tracks detected, which is not possible in HLS;`
								+ ` treating them as unpaired.`,
							);
							illegalPairingDetected = true;
						}

						continue;
					}

					// Key-packets-only tracks can neither pair with nor be paired with other tracks
					if (
						(track.isVideoTrack() && track.metadata.hasOnlyKeyPackets)
						|| (otherTrack.isVideoTrack() && otherTrack.metadata.hasOnlyKeyPackets)
					) {
						if (!keyPacketsOnlyPairingWarned) {
							Logging._warn(
								`A key-packets-only video track is pairable with another track, which is not`
								+ ` possible in HLS; treating them as unpaired.`,
							);
							keyPacketsOnlyPairingWarned = true;
						}

						continue;
					}

					let groupTracks = pairableGroups.get(otherTrack.source._codec);
					if (!groupTracks) {
						pairableGroups.set(otherTrack.source._codec, groupTracks = []);
					}

					groupTracks.push(otherTrack);
				}

				for (const [, pairableTracks] of pairableGroups) {
					const key = pairableTracks.map(x => x.id).join('-');
					const group = groups.find(x => x.key === key);
					if (!group) {
						groups.push({
							name: pairableTracks[0]!.type + '-' + (groups.length + 1),
							key,
							tracks: pairableTracks,
							needsEmit: false,
							firstNoUri: false,
						});
					}

					let assignedGroups = groupAssignment.get(track);
					if (!assignedGroups) {
						groupAssignment.set(track, assignedGroups = []);
					}
					assignedGroups.push(key);
				}
			}

			const mainType: TrackType = hasVideo ? 'video' : 'audio';

			const variantStreams: {
				tracks: OutputTrack[];
				linkedGroup: typeof groups[number] | null;
			}[] = [];

			const unpairedVideoTracks: OutputTrack[] = [];
			const unpairedAudioTracks: OutputTrack[] = [];

			const deduceSegmentFormat = (tracks: OutputTrack[]) => {
				const codecs: MediaCodec[] = [];
				let videoCount = 0;
				let audioCount = 0;
				let requiresTransformationMetadata = false;

				let candidate: OutputFormat | null = null;
				let candidateScore = -Infinity;

				for (const track of tracks) {
					if (track.isVideoTrack()) {
						videoCount++;
						requiresTransformationMetadata ||= (track.metadata.rotation ?? 0) !== 0
							|| !!track.metadata.flip
							|| !!track.metadata.transformationMatrix;
					} else if (track.isAudioTrack()) {
						audioCount++;
					}

					codecs.push(track.source._codec);
				}

				for (const format of toArray(this.format._options.segmentFormat)) {
					const supportedCodecs = format.getSupportedCodecs();
					const trackCounts = format.getSupportedTrackCounts();

					if (codecs.some(codec => !supportedCodecs.includes(codec))) {
						continue;
					}

					if (videoCount < trackCounts.video.min || videoCount > trackCounts.video.max) {
						continue;
					}

					if (audioCount < trackCounts.audio.min || audioCount > trackCounts.audio.max) {
						continue;
					}

					let score = 0;
					if (requiresTransformationMetadata && format.supportsVideoTransformationMetadata) {
						score++;
					}

					if (score > candidateScore) {
						candidate = format;
						candidateScore = score;
					}
				}

				return candidate;
			};

			// Now, create the top-level variant streams
			for (const track of this.output.tracks) {
				const assignedGroupKeys = groupAssignment.get(track);
				if (assignedGroupKeys) {
					assert(assignedGroupKeys.length > 0);

					if (track.type !== mainType) {
						continue;
					}

					for (const key of assignedGroupKeys) {
						const group = groups.find(x => x.key === key);
						assert(group);

						if (assignedGroupKeys.length === 1 && group.tracks.length === 1) {
							const otherGroupKeys = groupAssignment.get(group.tracks[0]!);
							assert(otherGroupKeys !== undefined);

							if (otherGroupKeys.length === 1) {
								const otherGroup = groups.find(x => x.key === otherGroupKeys[0]!)!;

								if (otherGroup.tracks.length === 1) {
									assert(otherGroup.tracks[0] === track);

									const canSharePlaylist = !!deduceSegmentFormat([track, group.tracks[0]!]);
									if (canSharePlaylist) {
										variantStreams.push({
											tracks: [track, group.tracks[0]!],
											linkedGroup: null,
										});
										continue;
									}
								}
							}
						}

						variantStreams.push({
							tracks: [track],
							linkedGroup: group,
						});
						group.needsEmit = true;
					}
				} else {
					if (track.type === 'video') {
						unpairedVideoTracks.push(track);
					} else if (track.type === 'audio') {
						unpairedAudioTracks.push(track);
					}
				}
			}

			const getMetadataKeyForTrack = ({ metadata }: OutputTrack) => {
				let key = '';
				key += `${metadata.languageCode ?? UNDETERMINED_LANGUAGE}-`;
				key += `${metadata.name ?? ''}-`;
				key += `${metadata.disposition?.default ?? true}-`;
				key += `${metadata.disposition?.primary ?? false}-`;
				key += `${metadata.disposition?.forced ?? false}-`;

				return key;
			};

			// Video tracks that can't be paired with any other track always live on the top-level, the question is just
			// if they need to be separated into #EXT-X-MEDIA tags or not
			if (unpairedVideoTracks.length > 0) {
				// Key-packets-only tracks are standalone I-frame streams, so they can't be renditions within a group
				const iFrameTracks = unpairedVideoTracks.filter(x => x.isVideoTrack() && x.metadata.hasOnlyKeyPackets);
				const groupableTracks = unpairedVideoTracks.filter(x => !iFrameTracks.includes(x));
				const uniqueMetadata = new Set(groupableTracks.map(getMetadataKeyForTrack));

				if (uniqueMetadata.size > 1) {
					// They differ in metadata, emit as group
					const group: typeof groups[number] = {
						key: groupableTracks.map(x => x.id).join('-'),
						name: 'video-' + (groups.length + 1),
						tracks: groupableTracks,
						needsEmit: true,
						firstNoUri: true,
					};
					groups.push(group);

					variantStreams.push({
						tracks: [groupableTracks[0]!],
						linkedGroup: group,
					});

					for (const track of iFrameTracks) {
						variantStreams.push({
							tracks: [track],
							linkedGroup: null,
						});
					}
				} else {
					for (const track of unpairedVideoTracks) {
						variantStreams.push({
							tracks: [track],
							linkedGroup: null,
						});
					}
				}
			}

			// Audio tracks that can't be paired with any other track always live on the top-level, the question is just
			// if they need to be separated into #EXT-X-MEDIA tags or not
			if (unpairedAudioTracks.length > 0) {
				const uniqueMetadata = new Set(unpairedAudioTracks.map(getMetadataKeyForTrack));

				if (uniqueMetadata.size > 1) {
					// They differ in metadata, emit as group
					const group: typeof groups[number] = {
						key: unpairedAudioTracks.map(x => x.id).join('-'),
						name: 'audio-' + (groups.length + 1),
						tracks: unpairedAudioTracks,
						needsEmit: true,
						firstNoUri: true,
					};
					groups.push(group);

					variantStreams.push({
						tracks: [unpairedAudioTracks[0]!],
						linkedGroup: group,
					});
				} else {
					for (const track of unpairedAudioTracks) {
						variantStreams.push({
							tracks: [track],
							linkedGroup: null,
						});
					}
				}
			}

			const registerPlaylist = async (tracks: OutputTrack[]) => {
				if (tracks.some(track => this.playlists.some(playlist => playlist.tracks.includes(track)))) {
					// Should be unreachable
					throw new Error('Internal error: track is already registered in a playlist.');
				}

				const format = deduceSegmentFormat(tracks);
				// We must find a format. If no format is found, that means we incorrectly gated track creation and
				// assignment at an earlier step.
				assert(format);

				const id = this.playlists.length + 1;
				const path = await this.getPlaylistPath({
					n: id,
					tracks,
					segmentFormat: format,
				});
				validatePlaylistPath(path);

				const playlist: Playlist = {
					id: this.playlists.length + 1,
					path,
					tracks,
					segmentFormat: format,
					currentSegmentStartTimestamp: null,
					currentSegmentStartTimestampIsFixed: false,
					nextSegmentId: 1,
					initSegment: null,
					writtenSegments: [],
					peakBitrate: null,
					averageBitrate: null,
					mediaSequence: 0,
					done: false,
					singleFile: null,
					mutex: new AsyncMutex(),
				};
				this.playlists.push(playlist);

				return playlist;
			};

			// Now, finally let's create all declarations. Each declaration maps to one #EXT-X-MEDIA or
			// #EXT-X-STREAM-INF tag in the final master playlist.
			for (const group of groups) {
				if (!group.needsEmit) {
					continue;
				}

				for (let i = 0; i < group.tracks.length; i++) {
					const track = group.tracks[i]!;

					let playlist = this.playlists.find(x => x.tracks[0]!.id === track.id);
					playlist ??= await registerPlaylist([track]);

					this.playlistDeclarations.push({
						playlist,
						groupId: group.name,
						noUri: group.firstNoUri && i === 0,
						references: [],
					});
				}
			}

			for (const variant of variantStreams) {
				// Since tracks can only be assigned to one playlist, the first track's ID acts as a "playlist key"
				let playlist = this.playlists.find(x => x.tracks[0]!.id === variant.tracks[0]!.id);
				playlist ??= await registerPlaylist(variant.tracks);

				this.playlistDeclarations.push({
					playlist,
					groupId: null,
					noUri: false,
					references: variant.linkedGroup
						? this.playlistDeclarations.filter(x => x.groupId === variant.linkedGroup!.name)
						: [],
				});
			}

			for (const track of this.output.tracks) {
				if (track.isVideoTrack() && track.metadata.decoderConfig) {
					this.getVideoTrackData(
						track,
						track.metadata.primingPacket ?? null,
						{ decoderConfig: track.metadata.decoderConfig },
					);
				} else if (track.isAudioTrack() && track.metadata.decoderConfig) {
					this.getAudioTrackData(
						track,
						track.metadata.primingPacket ?? null,
						{ decoderConfig: track.metadata.decoderConfig },
					);
				}
			}
		} finally {
			release();
		}
	}

	async getMimeType(): Promise<string> {
		return HLS_MIME_TYPE;
	}

	private allTracksAreKnown(playlist: Playlist) {
		for (const track of playlist.tracks) {
			if (!this.closedTracks.has(track) && !this.trackDatas.some(x => x.track === track)) {
				return false; // We haven't seen a sample from this open track yet
			}
		}

		return true;
	}

	override async onTrackClose(track: OutputTrack) {
		const playlist = this.playlists.find(x => x.tracks.includes(track));
		assert(playlist); // If there isn't one then the assignment algo failed innit

		const release = await playlist.mutex.acquire();

		try {
			this.closedTracks.add(track);

			// Another track of the playlist may have closed alongside this one and already finished the playlist,
			// hence this check
			if (!playlist.done) {
				await this.advancePlaylist(playlist);
			}
		} finally {
			release();
		}
	}

	getVideoTrackData(track: OutputVideoTrack, packet: EncodedPacket | null, meta?: EncodedVideoChunkMetadata) {
		let trackData = this.trackDatas.find(x => x.track === track) as HlsVideoTrackData;
		if (trackData) {
			return trackData;
		}

		validateVideoChunkMetadata(meta, track.source._codec);

		assert(meta);
		assert(meta?.decoderConfig);

		const playlists = this.playlists.filter(x => x.tracks.includes(track));
		assert(playlists.length === 1);

		trackData = {
			track,
			packets: [],
			playlist: playlists[0]!,
			info: {
				type: 'video',
				decoderConfig: meta.decoderConfig,
				primingPacket: packet,
			},
		};
		this.trackDatas.push(trackData);

		return trackData;
	}

	getAudioTrackData(track: OutputAudioTrack, packet: EncodedPacket | null, meta?: EncodedAudioChunkMetadata) {
		let trackData = this.trackDatas.find(x => x.track === track) as HlsAudioTrackData;
		if (trackData) {
			return trackData;
		}

		validateAudioChunkMetadata(meta, track.source._codec);

		assert(meta);
		assert(meta?.decoderConfig);

		const playlists = this.playlists.filter(x => x.tracks.includes(track));
		assert(playlists.length === 1);

		trackData = {
			track,
			packets: [],
			playlist: playlists[0]!,
			info: {
				type: 'audio',
				decoderConfig: meta.decoderConfig,
				primingPacket: packet,
			},
		};
		this.trackDatas.push(trackData);

		return trackData;
	}

	async addEncodedVideoPacket(
		track: OutputVideoTrack,
		packet: EncodedPacket,
		meta?: EncodedVideoChunkMetadata,
	) {
		const trackData = this.getVideoTrackData(track, packet, meta);
		const playlist = trackData.playlist;

		const release = await playlist.mutex.acquire();

		try {
			this.validateTimestamp(track, packet.timestamp, packet.type === 'key');
			trackData.packets.push(packet);
			this.firstPacketTimestamp ??= packet.timestamp;

			if (playlist.currentSegmentStartTimestamp === null) {
				playlist.currentSegmentStartTimestamp = packet.timestamp;
			} else if (!playlist.currentSegmentStartTimestampIsFixed) {
				playlist.currentSegmentStartTimestamp = Math.min(
					playlist.currentSegmentStartTimestamp,
					packet.timestamp,
				);
			}

			await this.advancePlaylist(playlist);
		} finally {
			release();
		}
	}

	async addEncodedAudioPacket(
		track: OutputAudioTrack,
		packet: EncodedPacket,
		meta?: EncodedAudioChunkMetadata,
	) {
		const trackData = this.getAudioTrackData(track, packet, meta);
		const playlist = trackData.playlist;

		const release = await playlist.mutex.acquire();

		try {
			this.validateTimestamp(track, packet.timestamp, packet.type === 'key');
			trackData.packets.push(packet);
			this.firstPacketTimestamp ??= packet.timestamp;

			if (playlist.currentSegmentStartTimestamp === null) {
				playlist.currentSegmentStartTimestamp = packet.timestamp;
			} else if (!playlist.currentSegmentStartTimestampIsFixed) {
				playlist.currentSegmentStartTimestamp = Math.min(
					playlist.currentSegmentStartTimestamp,
					packet.timestamp,
				);
			}

			await this.advancePlaylist(playlist);
		} finally {
			release();
		}
	}

	async addSubtitleCue(
		// eslint-disable-next-line @typescript-eslint/no-unused-vars
		track: OutputSubtitleTrack,
		// eslint-disable-next-line @typescript-eslint/no-unused-vars
		cue: SubtitleCue,
		// eslint-disable-next-line @typescript-eslint/no-unused-vars
		meta?: SubtitleMetadata,
	) {
		throw new Error('Unreachable.');
	}

	async advancePlaylist(playlist: Playlist) {
		assert(!playlist.done);

		if (!this.allTracksAreKnown(playlist)) {
			return;
		}

		const trackDatas = this.trackDatas.filter(x => playlist.tracks.includes(x.track));
		const allClosed = trackDatas.every(x => this.closedTracks.has(x.track));

		if (playlist.currentSegmentStartTimestamp === null) {
			// All tracks are known but we never received any data. Tracks that declared themselves up front are known
			// before their first packet, so we can only call it a day once they're actually closed.
			if (allClosed) {
				await this.onPlaylistDone(playlist);
			}

			return;
		}

		const videoTrack = trackDatas.find(x => x.info.type === 'video') as HlsVideoTrackData | undefined;
		const audioTrack = trackDatas.find(x => x.info.type === 'audio') as HlsAudioTrackData | undefined;
		const videoTrackIsClosed = !!videoTrack && this.closedTracks.has(videoTrack.track);
		const audioTrackIsClosed = !!audioTrack && this.closedTracks.has(audioTrack.track);

		// RFC 8216: "The EXT-X-I-FRAMES-ONLY tag indicates that each Media Segment in the Playlist describes a
		// single I-frame"
		const isKeyPacketsOnly = playlist.tracks[0]!.isVideoTrack()
			&& playlist.tracks[0].metadata.hasOnlyKeyPackets;

		// Loop in case we can finalize multiple segments
		while (true) {
			// This here is the core segmentation logic. The segmentation logic figures out which packets are to be
			// written into the next segment, and if we can write a segment at all. If tracks are still open and have
			// not provided sufficient media data, no segment will be written. The packets will be added to the segment
			// to maximize its duration AND keep it from exceeding the target duration. This condition is extended with
			// a key frame rule for video, meaning the algorithm must guarantee that every segment with video data
			// begins with a video key frame.
			//
			// The logic is quite complex but is solved in a straight-forward way: all possible permutations of the
			// problem are checked in a nested if-else structure, making sure all cases behave correctly. This was the
			// easiest, least error-prone way I found to express this behavior.

			const currentSegmentEndTimestamp = playlist.currentSegmentStartTimestamp + this.targetSegmentDuration;

			// These store the index (exclusive) until when packets can be added to the next segment
			let videoEndIndex = 0;
			let audioEndIndex = 0;

			if (videoTrack && (!videoTrackIsClosed || videoTrack.packets.length > 0)) {
				// A video track is active (and maybe an audio track too)
				const allBelow = videoTrack.packets.every(x => x.timestamp < currentSegmentEndTimestamp);

				let bestKeyPacket: EncodedPacket | null = null;
				let bestKeyPacketIndex: number | null = null;

				if (allBelow && !isKeyPacketsOnly) {
					if (!videoTrackIsClosed) {
						// Not enough data yet
						return;
					}
				} else {
					// Find the best key packet timestamp
					for (let i = 0; i < videoTrack.packets.length; i++) {
						const packet = videoTrack.packets[i]!;

						if (bestKeyPacket !== null && packet.timestamp > currentSegmentEndTimestamp) {
							break;
						}

						if (i > 0 && packet.type === 'key') {
							bestKeyPacket = packet;
							bestKeyPacketIndex = i;

							if (isKeyPacketsOnly) {
								break;
							}
						}
					}
				}

				if (bestKeyPacketIndex !== null) {
					videoEndIndex = bestKeyPacketIndex;

					if (audioTrack) {
						// The audio track must go at least until the video key frame
						const index = audioTrack.packets.findIndex(x => x.timestamp >= bestKeyPacket!.timestamp);
						if (index !== -1) {
							audioEndIndex = index;
						} else {
							if (audioTrackIsClosed) {
								audioEndIndex = audioTrack.packets.length;
							} else {
								return;
							}
						}
					}
				} else {
					if (!videoTrackIsClosed) {
						return;
					}

					// Include the entire rest of the video (since there's no key frame to split it on)
					videoEndIndex = videoTrack.packets.length;
					const maxIndex = arrayArgmax(videoTrack.packets, x => x.timestamp);
					const maxPacket = videoTrack.packets[maxIndex];
					assert(maxPacket);

					if (audioTrack) {
						if (maxPacket.timestamp < currentSegmentEndTimestamp) {
							// The audio must go until at least the start of the next segment
							const index = audioTrack.packets.findIndex(x => x.timestamp >= currentSegmentEndTimestamp);
							if (index !== -1) {
								audioEndIndex = index;
							} else {
								if (audioTrackIsClosed) {
									audioEndIndex = audioTrack.packets.length;
								} else {
									return;
								}
							}
						} else {
							// The audio must go beyond the last video packet
							const index = audioTrack.packets.findIndex(x => x.timestamp > maxPacket.timestamp);
							if (index !== -1) {
								audioEndIndex = index;
							} else {
								if (audioTrackIsClosed) {
									audioEndIndex = audioTrack.packets.length;
								} else {
									return;
								}
							}
						}
					}
				}
			} else if (audioTrack && (!audioTrackIsClosed || audioTrack.packets.length > 0)) {
				// There's only an audio track active

				const allBelow = audioTrack.packets.every(x => x.timestamp < currentSegmentEndTimestamp);

				if (allBelow) {
					if (audioTrackIsClosed) {
						// We can write all packets since they're all below
						audioEndIndex = audioTrack.packets.length;
					} else {
						// We don't know enough packets yet
						return;
					}
				} else {
					// Aim to make the segment at most as long as desired
					const index = findLastIndex(audioTrack.packets, x => x.timestamp <= currentSegmentEndTimestamp);
					audioEndIndex = Math.max(index, 1); // Always include at least the first packet
				}
			}

			if (videoEndIndex === 0 && audioEndIndex === 0) {
				// No more segments to write - if all tracks are closed, this playlist is done
				if (allClosed) {
					await this.onPlaylistDone(playlist);
				}

				return;
			}

			// We can finalize a new segment!

			let segmentInfo: HlsOutputSegmentInfo | null = null;
			let relativeSegmentPath: string;
			let fullSegmentPath: string;

			assert(this.output._target instanceof PathedTarget);
			const pathedTarget = this.output._target;

			if (this.singleFilePerPlaylist) {
				if (playlist.singleFile === null) {
					// INTENTIONALLY shadow the outside `segmentInfo` because we don't want to set it.
					// In single-file mode, onSegment is called once in onPlaylistDone instead of per-segment,
					// so the outer `segmentInfo` intentionally stays null in this case.
					const segmentInfo: HlsOutputSegmentInfo = {
						n: playlist.nextSegmentId,
						format: playlist.segmentFormat,
						isSingleFile: true,
						playlist: toPlaylistInfo(playlist),
					};

					relativeSegmentPath = await this.getSegmentPath(segmentInfo);
					validateSegmentPath(relativeSegmentPath);

					fullSegmentPath = joinPaths(
						joinPaths(pathedTarget.rootPath, playlist.path),
						relativeSegmentPath,
					);

					const target = await this.output._getTarget({
						path: fullSegmentPath,
						isRoot: false,
						mimeType: playlist.segmentFormat.mimeType,
					});

					let fragmentedIsobmffOutput: FragmentedIsobmffOutput | null = null;
					if (playlist.segmentFormat._isFragmentedIsobmff()) {
						// HARDCODED SPECIAL CASE: Single file mode with fragmented ISOBMFF. Instead of merely creating
						// a single file that's the concatenation of a bunch of smaller files, here we actually produce
						// one single fMP4 file that holds all segment media data. The result is a segments file that is
						// playable standalone!

						fragmentedIsobmffOutput = {
							output: new Output({
								format: playlist.segmentFormat,
								target,
							}),
							videoSource: null,
							audioSource: null,
							firstMoofPosition: null,
							currentFileSize: 0,
						};

						target.on('write', ({ end }) => {
							fragmentedIsobmffOutput!.currentFileSize = Math.max(
								fragmentedIsobmffOutput!.currentFileSize,
								end,
							);
						});

						// Make sure it never auto-finalizes fragments for us; we take full control of fragment
						// finalization to line it up perfectly with segments
						const muxer = fragmentedIsobmffOutput.output._muxer as IsobmffMuxer;
						muxer.minimumFragmentDuration = Infinity;

						// Intercept the first moof to determine init segment size
						const originalOnMoof = muxer.formatOptions.onMoof;
						muxer.formatOptions.onMoof = (data, position, timestamp) => {
							fragmentedIsobmffOutput!.firstMoofPosition = position;
							originalOnMoof?.(data, position, timestamp);
							muxer.formatOptions.onMoof = originalOnMoof;
						};

						// Add video track
						if (videoTrack) {
							fragmentedIsobmffOutput.videoSource = new EncodedVideoPacketSource(
								(videoTrack.track as OutputVideoTrack).source._codec,
							);
							fragmentedIsobmffOutput.output.addVideoTrack(
								fragmentedIsobmffOutput.videoSource,
								{
									...videoTrack.track.metadata,
									decoderConfig: videoTrack.info.decoderConfig,
									primingPacket: videoTrack.info.primingPacket ?? undefined,
								},
							);
						}

						// Add audio track
						if (audioTrack) {
							fragmentedIsobmffOutput.audioSource = new EncodedAudioPacketSource(
								(audioTrack.track as OutputAudioTrack).source._codec,
							);
							fragmentedIsobmffOutput.output.addAudioTrack(
								fragmentedIsobmffOutput.audioSource,
								{
									...audioTrack.track.metadata,
									decoderConfig: audioTrack.info.decoderConfig,
									primingPacket: audioTrack.info.primingPacket ?? undefined,
								},
							);
						}

						await fragmentedIsobmffOutput.output.start();
					} else {
						target._start();
					}

					playlist.singleFile = {
						target,
						path: relativeSegmentPath,
						nextOffset: 0,
						info: segmentInfo,
						fragmentedIsobmffOutput,
					};
				} else {
					relativeSegmentPath = playlist.singleFile.path;
					fullSegmentPath = joinPaths(
						joinPaths(pathedTarget.rootPath, playlist.path),
						relativeSegmentPath,
					);
				}
			} else {
				segmentInfo = {
					n: playlist.nextSegmentId,
					format: playlist.segmentFormat,
					isSingleFile: false,
					playlist: toPlaylistInfo(playlist),
				};

				relativeSegmentPath = await this.getSegmentPath(segmentInfo);
				validateSegmentPath(relativeSegmentPath);

				fullSegmentPath = joinPaths(joinPaths(pathedTarget.rootPath, playlist.path), relativeSegmentPath);
				playlist.nextSegmentId++;
			}

			let segmentSize = 0;
			let outputTarget: Target | null = null;
			let maxEndTimestamp = -Infinity;

			let output: Output | null = null;
			let videoSource: EncodedVideoPacketSource | null = null;
			let audioSource: EncodedAudioPacketSource | null = null;

			try {
				if (playlist.singleFile?.fragmentedIsobmffOutput) {
					output = playlist.singleFile.fragmentedIsobmffOutput.output;
					videoSource = playlist.singleFile.fragmentedIsobmffOutput.videoSource;
					audioSource = playlist.singleFile.fragmentedIsobmffOutput.audioSource;
				} else {
					// Create the output for this segment
					output = new Output({
						// TEMP HACK: MP3 makes little sense with the Xing header, because many players interpret it
						// as mid-stream silence. But it's enabled by default, and changing that would be breaking.
						// So, it's a hardcoded special case for now. In the future, we should deprecate arbitrary
						// segment formats for HLS and switch to special HLS-specific segment formats which can carry
						// their own logic.
						format: playlist.segmentFormat._withoutXingHeader(),
						target: new PathedTarget(
							fullSegmentPath,
							async (request: TargetRequest) => {
								const proxiedRequest: TargetRequest = {
									...request,
									isRoot: false,
								};

								if (request.isRoot) {
									if (playlist.singleFile) {
										const slice = playlist.singleFile.target.slice(playlist.singleFile.nextOffset);
										slice.on('write', ({ end }) => segmentSize = Math.max(segmentSize, end));

										return slice;
									} else {
										const target = await this.output._getTarget(proxiedRequest);
										outputTarget = target;
										target.on('write', ({ end }) => segmentSize = Math.max(segmentSize, end));

										return target;
									}
								}

								return this.output._getTarget(proxiedRequest);
							},
						),
						initTarget: async () => {
							if (playlist.initSegment) {
								// We already have an init segment from a previous segment
								return new NullTarget();
							}

							if (playlist.singleFile) {
								playlist.initSegment = {
									path: playlist.singleFile.path,
									duration: 0,
									timestamp: 0,
									byteSize: 0,
									byteOffset: 0,
									info: null,
								};

								const slice = playlist.singleFile.target.slice(playlist.singleFile.nextOffset);
								slice.on('write', ({ end }) => {
									playlist.initSegment!.byteSize = Math.max(playlist.initSegment!.byteSize, end);
								});
								slice.on('finalized', () => {
									playlist.singleFile!.nextOffset = playlist.initSegment!.byteSize;
								});

								return slice;
							} else {
								const playlistInfo = toPlaylistInfo(playlist);
								const initPath = await this.getInitPath(playlistInfo);
								validateInitPath(initPath);

								playlist.initSegment = {
									path: initPath,
									duration: 0,
									timestamp: 0,
									byteSize: 0,
									byteOffset: null,
									info: null,
								};

								const fullInitPath = joinPaths(
									joinPaths(pathedTarget.rootPath, playlist.path),
									initPath,
								);
								const target = await this.output._getTarget({
									path: fullInitPath,
									isRoot: false,
									mimeType: playlist.segmentFormat.mimeType,
								});
								target.on('write', ({ end }) => {
									playlist.initSegment!.byteSize = Math.max(playlist.initSegment!.byteSize, end);
								});
								target.on('finalized', () => {
									this.format._options.onInit?.(target, playlistInfo);
								});

								return target;
							}
						},
					});

					if (videoTrack) {
						// Always add the track, no matter if it has packets or not (maintains underlying IDs)
						videoSource = new EncodedVideoPacketSource(
							(videoTrack.track as OutputVideoTrack).source._codec,
						);
						output.addVideoTrack(videoSource, {
							...videoTrack.track.metadata,
							decoderConfig: videoTrack.info.decoderConfig,
							primingPacket: videoTrack.info.primingPacket ?? undefined,
							maximumPacketCount: videoEndIndex,
						});
					}

					if (audioTrack) {
						// Always add the track, no matter if it has packets or not (maintains underlying IDs)
						audioSource = new EncodedAudioPacketSource(
							(audioTrack.track as OutputAudioTrack).source._codec,
						);
						output.addAudioTrack(audioSource, {
							...audioTrack.track.metadata,
							decoderConfig: audioTrack.info.decoderConfig,
							primingPacket: audioTrack.info.primingPacket ?? undefined,
							maximumPacketCount: audioEndIndex,
						});

						if (!playlist.segmentFormat.supportsTimestampedMediaData && audioEndIndex > 0) {
							// The media itself carries no timestamps, so let's write an ID3v2 PRIV frame. The formats
							// that the spec permits (MP3, ADTS) understand this just fine.
							const firstTimestamp = this.toMediaTimestamp(audioTrack.packets[0]!.timestamp);
							const pts = secondsToMpegTsTimestamp(firstTimestamp);

							const priv = new Uint8Array(TIMESTAMP_PRIV_OWNER.length + 1 + 8);
							priv.set(textEncoder.encode(TIMESTAMP_PRIV_OWNER), 0);
							const view = toDataView(priv);
							view.setUint32(TIMESTAMP_PRIV_OWNER.length + 1, Math.floor(pts / 2 ** 32));
							view.setUint32(TIMESTAMP_PRIV_OWNER.length + 5, pts % 2 ** 32);

							output.setMetadataTags({ raw: { PRIV: priv } });
						}
					}

					await output.start();
				}

				// Add all of the packets

				if (videoTrack) {
					assert(videoSource);
					const meta = { decoderConfig: videoTrack.info.decoderConfig };

					for (let i = 0; i < videoEndIndex; i++) {
						const packet = videoTrack.packets[i]!;

						const offsetPacket = packet.clone({
							timestamp: this.toMediaTimestamp(packet.timestamp),
						});

						await videoSource.add(offsetPacket, meta);
						maxEndTimestamp = Math.max(maxEndTimestamp, packet.timestamp + packet.duration);
					}
				}

				if (audioTrack) {
					assert(audioSource);
					const meta = { decoderConfig: audioTrack.info.decoderConfig };

					for (let i = 0; i < audioEndIndex; i++) {
						const packet = audioTrack.packets[i]!;

						const offsetPacket = packet.clone({
							timestamp: this.toMediaTimestamp(packet.timestamp),
						});

						await audioSource.add(offsetPacket, meta);
						maxEndTimestamp = Math.max(maxEndTimestamp, packet.timestamp + packet.duration);
					}
				}

				if (playlist.singleFile?.fragmentedIsobmffOutput) {
					const muxer = playlist.singleFile.fragmentedIsobmffOutput.output._muxer as IsobmffMuxer;
					await muxer.forceFragmentFinalization();

					if (
						playlist.singleFile.fragmentedIsobmffOutput.firstMoofPosition !== null
						&& !playlist.initSegment
					) {
						playlist.initSegment = {
							path: playlist.singleFile.path,
							duration: 0,
							timestamp: 0,
							byteSize: playlist.singleFile.fragmentedIsobmffOutput.firstMoofPosition,
							byteOffset: 0,
							info: null,
						};
						playlist.singleFile.nextOffset = playlist.singleFile.fragmentedIsobmffOutput.firstMoofPosition;
					}

					segmentSize
						= playlist.singleFile.fragmentedIsobmffOutput.currentFileSize - playlist.singleFile.nextOffset;
				} else {
					await output.finalize();
				}
			} catch (e) {
				await output?.cancel();
				throw e;
			}

			if (segmentInfo) {
				assert(outputTarget);
				this.format._options.onSegment?.(outputTarget, segmentInfo);
			}

			if (videoEndIndex > 0) {
				assert(videoTrack);
				videoTrack.packets.splice(0, videoEndIndex);
			}
			if (audioEndIndex > 0) {
				assert(audioTrack);
				audioTrack.packets.splice(0, audioEndIndex);
			}

			let minNextTimestamp = Infinity;
			if (videoTrack && videoTrack.packets.length > 0) {
				minNextTimestamp = videoTrack.packets[0]!.timestamp;
			}
			if (audioTrack && audioTrack.packets.length > 0) {
				minNextTimestamp = Math.min(minNextTimestamp, audioTrack.packets[0]!.timestamp);
			}

			const nextSegmentStartTimestamp = minNextTimestamp < Infinity
				? minNextTimestamp
				: maxEndTimestamp; // Happens for the last segment for example
			assert(Number.isFinite(nextSegmentStartTimestamp));

			const segmentDuration = nextSegmentStartTimestamp - playlist.currentSegmentStartTimestamp;
			assert(segmentDuration >= 0);

			playlist.writtenSegments.push({
				path: relativeSegmentPath,
				duration: segmentDuration,
				timestamp: playlist.currentSegmentStartTimestamp,
				byteSize: segmentSize,
				byteOffset: playlist.singleFile
					? playlist.singleFile.nextOffset
					: null,
				info: segmentInfo ?? null,
			});

			this.globalTargetDuration = Math.max(this.globalTargetDuration, segmentDuration);

			playlist.currentSegmentStartTimestamp = nextSegmentStartTimestamp;
			playlist.currentSegmentStartTimestampIsFixed = true; // After the first segment, the timestamp is now fixed

			if (playlist.singleFile) {
				playlist.singleFile.nextOffset += segmentSize;
			}

			if (this.isLive) {
				while (playlist.writtenSegments.length > this.maxLiveSegmentCount) {
					const popped = playlist.writtenSegments.shift()!;
					playlist.mediaSequence++;

					if (!this.singleFilePerPlaylist) {
						assert(popped.info);
						this.format._options.onSegmentPopped?.(popped.path, popped.info);
					}
				}

				await this.writePlaylist(playlist);
				await this.tryWriteMasterPlaylist();
			}
		}
	}

	private toMediaTimestamp(timestamp: number) {
		// The media's own timestamps are decoupled from the input timestamps (which may well be huge Unix timestamps)
		assert(this.firstPacketTimestamp !== null);
		return timestamp - this.firstPacketTimestamp + this.mediaTimestampBase;
	}

	private async onPlaylistDone(playlist: Playlist) {
		assert(!playlist.done);
		playlist.done = true;

		if (playlist.singleFile) {
			if (playlist.singleFile.fragmentedIsobmffOutput) {
				await playlist.singleFile.fragmentedIsobmffOutput.output.finalize();
			} else {
				await playlist.singleFile.target._flush();
				await playlist.singleFile.target._finalize();
			}

			this.format._options.onSegment?.(playlist.singleFile.target, playlist.singleFile.info);
		}

		if (this.isLive) {
			await this.writePlaylist(playlist);

			if (playlist.writtenSegments.length === 0) {
				await this.tryWriteMasterPlaylist();
			}
		}
	}

	private updatePlaylistBitrates(playlist: Playlist, targetDuration: number) {
		const segments = playlist.writtenSegments;

		let peakBitrate = 0;
		let totalBits = 0;
		let totalDuration = 0;

		// Per spec, peak bitrate is the largest bit rate of any contiguous set of segments whose total duration is
		// between 0.5 and 1.5 times the target duration
		for (let i = 0; i < segments.length; i++) {
			totalDuration += segments[i]!.duration;

			let windowBytes = 0;
			let windowDuration = 0;

			for (let j = i; j < segments.length; j++) {
				windowBytes += segments[j]!.byteSize;
				windowDuration += segments[j]!.duration;

				if (windowDuration >= 0.5 * targetDuration && windowDuration <= 1.5 * targetDuration) {
					peakBitrate = Math.max(peakBitrate, 8 * windowBytes / windowDuration);
				}

				if (windowDuration > 1.5 * targetDuration) {
					break;
				}
			}
		}

		// Fallback: if no contiguous set falls within the range, use per-segment max
		if (peakBitrate === 0) {
			for (const segment of segments) {
				const segmentDuration = segment.duration || 1; // To catch 0-duration segments which can happen
				peakBitrate = Math.max(peakBitrate, 8 * segment.byteSize / segmentDuration);
			}
		}

		for (const segment of segments) {
			totalBits += 8 * segment.byteSize;
		}

		let averageBitrate = totalBits / (totalDuration || 1);

		if (segments.length === 0) {
			// No data to measure, meaning a bandwidth of zero. This breaks some HLS players, so let's use a sensible
			// default instead
			for (const track of playlist.tracks) {
				const trackData = this.trackDatas.find(x => x.track === track);
				let trackPeakBitrate = track.source._nominalBitrate ?? track.metadata.bitrate ?? 0;
				averageBitrate += track.source._nominalBitrate ?? track.metadata.averageBitrate ?? 0;

				if (trackPeakBitrate === 0) {
					const mediumQuality = new Quality('medium');

					if (track.isVideoTrack()) {
						const decoderConfig = trackData?.info.decoderConfig as VideoDecoderConfig | undefined;
						trackPeakBitrate = mediumQuality._toVideoBitrate(
							track.source._codec,
							decoderConfig?.codedWidth ?? 1920, // Need to assume a resolution
							decoderConfig?.codedHeight ?? 1080,
						);
					} else if (track.isAudioTrack()) {
						const decoderConfig = trackData?.info.decoderConfig as AudioDecoderConfig | undefined;
						trackPeakBitrate = mediumQuality._toAudioBitrate(
							track.source._codec,
							decoderConfig?.numberOfChannels ?? 2,
						) ?? 0;
					}
				}

				peakBitrate += trackPeakBitrate;
			}
		}

		playlist.peakBitrate = peakBitrate;
		playlist.averageBitrate = averageBitrate;
	}

	private async writePlaylist(playlist: Playlist) {
		assert(this.output._target instanceof PathedTarget);
		const pathedTarget = this.output._target;

		// In live mode, target duration is not allowed to change, so we use the nominal value. It must be a
		// "decimal-integer", and it's rounded like the EXTINF values first so that float noise doesn't mess it up
		const targetDuration = Math.max(
			Math.ceil(+(this.isLive ? this.targetSegmentDuration : this.globalTargetDuration).toFixed(12)),
			1, // A target duration of 0 is kinda weird
		);

		this.updatePlaylistBitrates(playlist, targetDuration);

		let hasByteOffsets = false;
		for (const segment of playlist.writtenSegments) {
			hasByteOffsets ||= segment.byteOffset !== null;
		}

		const isKeyPacketsOnly = playlist.tracks[0]!.isVideoTrack()
			&& playlist.tracks[0].metadata.hasOnlyKeyPackets;

		let version = 3;
		if (isKeyPacketsOnly || hasByteOffsets) {
			version = 4;
		}
		if (playlist.initSegment) {
			version = 5;
		}
		if (playlist.initSegment && !isKeyPacketsOnly) {
			// "if it contains the EXT-X-MAP tag in a Media Playlist that does not contain EXT-X-I-FRAMES-ONLY"
			version = 6;
		}

		const playlistPath = joinPaths(pathedTarget.rootPath, playlist.path);
		const playlistText = '#EXTM3U\n'
			+ `#EXT-X-VERSION:${version}\n`
			+ (!this.isLive ? '#EXT-X-PLAYLIST-TYPE:VOD\n' : '')
			+ `#EXT-X-TARGETDURATION:${targetDuration}\n`
			+ (Number.isFinite(this.maxLiveSegmentCount) ? `#EXT-X-MEDIA-SEQUENCE:${playlist.mediaSequence}\n` : '')
			+ '#EXT-X-INDEPENDENT-SEGMENTS\n'
			+ (isKeyPacketsOnly ? '#EXT-X-I-FRAMES-ONLY\n' : '')
			+ (playlist.initSegment
				? (`#EXT-X-MAP:URI="${playlist.initSegment.path}"`
					+ (playlist.initSegment.byteOffset !== null
						? `,BYTERANGE="${playlist.initSegment.byteSize}@${playlist.initSegment.byteOffset}"`
						: '')
					+ '\n')
				: '')
			+ '\n'
			+ (playlist.writtenSegments
				.map(segment => (
					`#EXTINF:${+segment.duration.toFixed(12)},\n` // Trailing comma mandated by spec
					+ (this.isRelativeToUnixEpoch
						? `#EXT-X-PROGRAM-DATE-TIME:${new Date(1000 * segment.timestamp).toISOString()}\n`
						: '')
					+ (segment.byteOffset !== null
						? `#EXT-X-BYTERANGE:${segment.byteSize}@${segment.byteOffset}\n`
						: '')
					+ `${segment.path}\n`
				))
				.join(''))
			+ (playlist.done
				? (playlist.writtenSegments.length > 0 ? '\n' : '') + '#EXT-X-ENDLIST\n'
				: '');

		this.format._options.onPlaylist?.(playlistText, toPlaylistInfo(playlist));

		const target = await this.output._getTarget({
			path: playlistPath,
			isRoot: false,
			mimeType: HLS_MIME_TYPE,
		});
		const writer = new Writer(target, true);
		writer.start();
		writer.write(textEncoder.encode(playlistText));

		await writer.flush();
		await writer.finalize();
	}

	private async writeMasterPlaylist() {
		assert(this.output._target instanceof PathedTarget);
		const pathedTarget = this.output._target;

		let masterPlaylistText = '#EXTM3U\n';
		let firstVariantWritten = false;

		let lastGroupId: string | null = null;
		let groupIdTrackCount = 0;
		let hasHadDefaultTrackInGroup = false;
		const namesInGroup = new Set<string>();

		for (const decl of this.playlistDeclarations) {
			if (decl.groupId === null) {
				const isKeyPacketsOnly = decl.playlist.tracks[0]!.isVideoTrack()
					&& decl.playlist.tracks[0].metadata.hasOnlyKeyPackets;

				const codecs: string[] = [];
				for (const track of decl.playlist.tracks) {
					const trackData = this.trackDatas.find(x => x.track === track);
					const codecString = trackData?.info.decoderConfig.codec ?? track.source._codec;
					codecs.push(toHlsCodecString(codecString));
				}

				let peakDeclBitrate = 0;
				let maxRefAverageBitrate = 0;

				// The variant's own playlist can be the URI-less rendition of the group it references, in which case
				// the group's renditions take the place of the variant's own media instead of adding to it
				const ownPlaylistIsReferenced = decl.references.some(x => x.playlist === decl.playlist);

				for (const ref of decl.references) {
					// The spec wants every codec of any rendition in the group listed
					for (const track of ref.playlist.tracks) {
						const trackData = this.trackDatas.find(x => x.track === track);
						const codecString = trackData?.info.decoderConfig.codec ?? track.source._codec;
						codecs.push(toHlsCodecString(codecString));
					}

					assert(ref.playlist.peakBitrate !== null);
					peakDeclBitrate = Math.max(peakDeclBitrate, ref.playlist.peakBitrate);
					maxRefAverageBitrate = Math.max(maxRefAverageBitrate, ref.playlist.averageBitrate ?? 0);
				}

				assert(decl.playlist.peakBitrate !== null);
				const ownPeakBitrate = ownPlaylistIsReferenced ? 0 : decl.playlist.peakBitrate;
				const ownAverageBitrate = ownPlaylistIsReferenced ? 0 : (decl.playlist.averageBitrate ?? 0);
				const totalPeakBitrate = ownPeakBitrate + peakDeclBitrate;
				const totalAverageBitrate = ownAverageBitrate + maxRefAverageBitrate;

				if (!firstVariantWritten) {
					masterPlaylistText += '\n';
					firstVariantWritten = true;
				}

				if (isKeyPacketsOnly) {
					masterPlaylistText += `#EXT-X-I-FRAME-STREAM-INF:`;
				} else {
					masterPlaylistText += `#EXT-X-STREAM-INF:`;
				}

				masterPlaylistText += `BANDWIDTH=${Math.ceil(totalPeakBitrate)}`;

				if (totalAverageBitrate > 0) {
					masterPlaylistText += `,AVERAGE-BANDWIDTH=${Math.ceil(totalAverageBitrate)}`;
				}

				masterPlaylistText += `,CODECS="${[...new Set(codecs)].join(',')}"`;

				const videoTrack = decl.playlist.tracks.find(x => x.isVideoTrack());
				if (videoTrack?.isVideoTrack()) {
					const trackData = this.trackDatas.find(x => x.track === videoTrack) as
						HlsVideoTrackData | undefined;
					const decoderConfig = trackData?.info.decoderConfig;
					if (decoderConfig) {
						assert(decoderConfig.codedWidth !== undefined);
						assert(decoderConfig.codedHeight !== undefined);

						let width = decoderConfig.codedWidth;
						let height = decoderConfig.codedHeight;

						if (
							decoderConfig.displayAspectWidth !== undefined
							&& decoderConfig.displayAspectHeight !== undefined
						) {
							const num = decoderConfig.displayAspectWidth * decoderConfig.codedHeight;
							const den = decoderConfig.displayAspectHeight * decoderConfig.codedWidth;

							if (num > den) {
								width = Math.round(width * num / den);
							} else {
								height = Math.round(height * den / num);
							}
						}

						if (
							videoTrack.metadata.rotation !== undefined
							&& videoTrack.metadata.rotation % 180 === 90
						) {
							[width, height] = [height, width];
						}

						masterPlaylistText += `,RESOLUTION=${width}x${height}`;
					}

					// FRAME-RATE is not defined for EXT-X-I-FRAME-STREAM-INF
					if (!isKeyPacketsOnly && videoTrack.metadata.frameRate !== undefined) {
						// Spec requires that frame rate be rounded to 3 decimal places
						masterPlaylistText += `,FRAME-RATE=${+videoTrack.metadata.frameRate.toFixed(3)}`;
					}
				}

				if (!isKeyPacketsOnly) {
					const groupIdForType = new Map<string, string>();
					for (const ref of decl.references) {
						assert(ref.groupId !== null);
						const type = ref.playlist.tracks[0]!.type;
						groupIdForType.set(type, ref.groupId);
					}

					for (const [type, id] of groupIdForType) {
						masterPlaylistText += `,${type.toUpperCase()}="${id}"`;
					}
				}

				if (isKeyPacketsOnly) {
					// EXT-X-I-FRAME-STREAM-INF is standalone with a URI attribute
					masterPlaylistText += `,URI="${decl.playlist.path}"`;
					masterPlaylistText += '\n';
				} else {
					masterPlaylistText += '\n';
					masterPlaylistText += `${decl.playlist.path}\n`;
				}
			} else {
				assert(decl.playlist.tracks.length === 1);

				const track = decl.playlist.tracks[0]!;
				const type = track.type;
				let name = track.metadata.name ?? null;
				const languageCode = track.metadata.languageCode;
				const disposition = track.metadata.disposition;

				if (lastGroupId === null || decl.groupId !== lastGroupId) {
					groupIdTrackCount = 0;
					masterPlaylistText += '\n';
					hasHadDefaultTrackInGroup = false;
					namesInGroup.clear();
				}
				lastGroupId = decl.groupId;
				groupIdTrackCount++;

				// Once subtitle tracks are supported, this logic is wrong (they need TYPE=SUBTITLES)
				masterPlaylistText += `#EXT-X-MEDIA:TYPE=${type.toUpperCase()},GROUP-ID="${decl.groupId}"`;

				if (name !== null && /[\n\r"]/.test(name)) {
					Logging._warn(
						'Dropping track name since it includes a line feed, carriage return, or double quote'
						+ ' character, which are not allowed in HLS playlist attributes.',
					);
					name = null;
				}

				// Name is required, so we have to set it to SOMETHING
				name ??= `${languageCode ?? decl.groupId}-${groupIdTrackCount}`;

				// The spec requires distinct names within a group
				let uniqueName = name;
				for (let i = 2; namesInGroup.has(uniqueName); i++) {
					uniqueName = `${name} (${i})`;
				}
				namesInGroup.add(uniqueName);

				masterPlaylistText += `,NAME="${uniqueName}"`;

				if (languageCode !== undefined) {
					masterPlaylistText += `,LANGUAGE="${languageCode}"`;
				}

				const dispositionPrimary = disposition?.primary ?? false;
				const dispositionDefault = disposition?.default ?? true;
				const dispositionForced = disposition?.forced ?? false;

				if (dispositionPrimary && !hasHadDefaultTrackInGroup) {
					// HLS's "DEFAULT" behaves like our "primary"
					masterPlaylistText += ',DEFAULT=YES';
					hasHadDefaultTrackInGroup = true; // Only one DEFAULT label per group allowed
				}

				if (dispositionPrimary || dispositionDefault) {
					masterPlaylistText += ',AUTOSELECT=YES';
				}

				if (dispositionForced && type === 'subtitle') { // The spec reserves FORCED for subtitle renditions
					masterPlaylistText += ',FORCED=YES';
				}

				if (type === 'audio') {
					const trackData = this.trackDatas.find(x => x.track === track) as
						HlsAudioTrackData | undefined;
					const decoderConfig = trackData?.info.decoderConfig;

					if (decoderConfig) {
						masterPlaylistText += `,CHANNELS="${decoderConfig.numberOfChannels}"`;
					}
				}

				if (!decl.noUri) {
					masterPlaylistText += `,URI="${decl.playlist.path}"`;
				}

				masterPlaylistText += '\n';
			}
		}

		this.format._options.onMaster?.(masterPlaylistText);

		const release = await this.mutex.acquire();

		try {
			let writer: Writer;
			if (this.numWrittenMasterPlaylists === 0) {
				// For the first master playlist write, we use the normal root writer getter, so that the target
				// returned by Output.target emits valid write events.
				writer = await this.output._getRootWriter(true);
			} else {
				// For subsequent master playlist writes, we *must* obtain a different target in order to overwrite
				// the file.
				const target = await this.output._getTarget({
					path: pathedTarget.rootPath,
					isRoot: true,
					mimeType: HLS_MIME_TYPE,
				});
				writer = new Writer(target, true);
				writer.start();
			}

			writer.write(textEncoder.encode(masterPlaylistText));

			await writer.flush();
			await writer.finalize();

			this.numWrittenMasterPlaylists++;
		} finally {
			release();
		}
	}

	private async tryWriteMasterPlaylist() {
		assert(this.isLive);

		// The master playlist is written once all playlists have either produced at least one segment or are done
		for (const playlist of this.playlists) {
			if (playlist.writtenSegments.length === 0 && !playlist.done) {
				return;
			}
		}

		await this.writeMasterPlaylist();
	}

	async finalize() {
		const releases = await Promise.all(this.playlists.map(p => p.mutex.acquire()));
		releases.forEach(release => release());

		for (const track of this.output.tracks) {
			this.closedTracks.add(track);
		}

		await Promise.all(this.playlists.map(playlist => (
			playlist.done ? Promise.resolve() : this.advancePlaylist(playlist)
		)));

		if (!this.isLive) {
			await Promise.all(this.playlists.map(playlist => this.writePlaylist(playlist)));
			await this.writeMasterPlaylist();
		}
	}
}

const validatePlaylistPath = (path: string) => {
	if (typeof path !== 'string') {
		throw new TypeError('options.getPlaylistPath must return or resolve to a string');
	}
	if (/[\n\r"]/.test(path)) {
		throw new TypeError(
			'Playlist paths cannot contain line feed, carriage return, or double quote characters.',
		);
	}
};

const validateSegmentPath = (path: string) => {
	if (typeof path !== 'string') {
		throw new TypeError('options.getSegmentPath must return or resolve to a string');
	}
	if (/[\n\r"]/.test(path)) {
		throw new TypeError(
			'Segment paths cannot contain line feed or carriage return characters.',
		);
	}
};

const validateInitPath = (path: string) => {
	if (typeof path !== 'string') {
		throw new TypeError('options.getInitPath must return or resolve to a string');
	}
	if (/[\n\r"]/.test(path)) {
		throw new TypeError(
			'Init paths cannot contain line feed, carriage return, or double quote characters.',
		);
	}
};

const toPlaylistInfo = (playlist: Playlist): HlsOutputPlaylistInfo => {
	return {
		n: playlist.id,
		tracks: playlist.tracks,
		segmentFormat: playlist.segmentFormat,
	};
};
